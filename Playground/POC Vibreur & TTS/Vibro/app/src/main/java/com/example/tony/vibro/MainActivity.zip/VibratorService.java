package com.example.tony.vibro;

import android.app.Application;
import android.content.Context;
import android.os.Vibrator;

/**
 * Created by tony on 17/04/2015.
 */
public class VibratorService {
    /**
     * Created by tony on 17/04/2015.
     */

       /* void cancelled(){
            Vibrator v = (Vibrator) this.getBaseContext().getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(200);
            try {
                wait(100);
            }
            catch (Exception ex){
                System.out.println("Unable to wait + " + ex);
            }
            v.vibrate(200);
        }*/

}
